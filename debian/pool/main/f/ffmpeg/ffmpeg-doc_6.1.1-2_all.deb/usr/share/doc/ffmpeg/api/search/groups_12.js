var searchData=
[
  ['vdpau_20decoder_20and_20renderer_0',['VDPAU Decoder and Renderer',['../group__lavc__codec__hwaccel__vdpau.html',1,'']]],
  ['version_20and_20build_20diagnostics_1',['Version and Build diagnostics',['../group__lavu__ver.html',1,'']]],
  ['video_20related_2',['Video related',['../group__lavu__video.html',1,'']]],
  ['videotoolbox_20decoder_3',['VideoToolbox Decoder',['../group__lavc__codec__hwaccel__videotoolbox.html',1,'']]]
];
