var searchData=
[
  ['pixel_20formats_0',['Pixel formats',['../group__lavc__misc__pixfmt.html',1,'']]],
  ['preprocessor_20string_20macros_1',['Preprocessor String Macros',['../group__preproc__misc.html',1,'']]],
  ['public_20metadata_20api_2',['Public Metadata API',['../group__metadata__api.html',1,'']]]
];
