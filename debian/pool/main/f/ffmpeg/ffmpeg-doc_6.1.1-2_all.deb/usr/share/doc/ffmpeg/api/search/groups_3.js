var searchData=
[
  ['data_20structures_0',['Data Structures',['../group__lavu__data.html',1,'']]],
  ['decoding_1',['Decoding',['../group__lavc__decoding.html',1,'']]],
  ['demuxers_2',['Demuxers',['../group__lavf__codec.html',1,'']]],
  ['demuxing_3',['Demuxing',['../group__lavf__decoding.html',1,'']]],
  ['deprecation_20guards_4',['Deprecation Guards',['../group__lavu__depr__guards.html',1,'']]],
  ['des_5',['DES',['../group__lavu__des.html',1,'']]],
  ['device_20context_20creation_20flags_6',['Device context creation flags',['../group__hwcontext__cuda.html',1,'']]],
  ['direct3d11_7',['Direct3D11',['../group__lavc__codec__hwaccel__d3d11va.html',1,'']]],
  ['display_20transformation_20matrix_20functions_8',['Display transformation matrix functions',['../group__lavu__video__display.html',1,'']]],
  ['dxva2_9',['DXVA2',['../group__lavc__codec__hwaccel__dxva2.html',1,'']]],
  ['dynamic_20array_10',['Dynamic Array',['../group__lavu__mem__dynarray.html',1,'']]]
];
