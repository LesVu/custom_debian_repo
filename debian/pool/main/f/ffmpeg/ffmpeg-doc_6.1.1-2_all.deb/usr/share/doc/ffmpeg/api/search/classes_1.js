var searchData=
[
  ['buffer_5fdata_0',['buffer_data',['../structbuffer__data.html',1,'']]]
];
