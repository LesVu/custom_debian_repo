var searchData=
[
  ['x_0',['x',['../structAVDeviceRect.html#a59c84ebbf20ec757079bcad8cf6938ba',1,'AVDeviceRect::x()'],['../structAVSubtitleRect.html#a0059c986f1ee3aab45c0f62f0709621b',1,'AVSubtitleRect::x()'],['../structAVCIExy.html#a081b20c1e491a7dc8abe75c3c5b49ad7',1,'AVCIExy::x()'],['../structAVDetectionBBox.html#a879fcbdb6516e1d7aa898e502846dd78',1,'AVDetectionBBox::x()'],['../structAVRC4.html#abc7f4de3a5ee2d586cff221c041141cb',1,'AVRC4::x()'],['../structAVVideoRect.html#ab2b8d0b937ea52fd0d2aa98827283c84',1,'AVVideoRect::x()']]],
  ['xtea_1',['XTEA',['../group__lavu__xtea.html',1,'']]],
  ['xtea_2eh_2',['xtea.h',['../xtea_8h.html',1,'']]],
  ['xvmc_3',['XvMC',['../group__lavc__codec__hwaccel__xvmc.html',1,'']]],
  ['xvmc_2eh_4',['xvmc.h',['../xvmc_8h.html',1,'']]],
  ['xvmc_5fid_5',['xvmc_id',['../structxvmc__pix__fmt.html#a6cadfce3023ac1a8730e675629f21430',1,'xvmc_pix_fmt']]],
  ['xvmc_5fpix_5ffmt_6',['xvmc_pix_fmt',['../structxvmc__pix__fmt.html',1,'']]]
];
