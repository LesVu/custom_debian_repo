var searchData=
[
  ['bounds_5finfo_5ft_0',['bounds_info_t',['../structbounds__info__t.html',1,'']]],
  ['bounds_5finfoxx_5ftemplate_1',['bounds_infoXX_template',['../structbounds__infoXX__template.html',1,'']]]
];
