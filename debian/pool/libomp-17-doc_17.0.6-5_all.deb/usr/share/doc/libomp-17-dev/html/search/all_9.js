var searchData=
[
  ['lazy_5fpriv_0',['lazy_priv',['../structkmp__taskred__flags.html#a8b474dd53a7cf8d81e9e490fad3f2ed9',1,'kmp_taskred_flags']]],
  ['llvm_26nbsp_3b_20openmp_2a_20runtime_20library_20interface_1',['LLVM&amp;nbsp; OpenMP* Runtime Library Interface',['../index.html',1,'']]],
  ['load_2',['load',['../classkmp__flag__atomic.html#a9c57a51bcea762ab69771bd2b1dd1202',1,'kmp_flag_atomic']]],
  ['loc_3',['loc',['../classkmp__flag__atomic.html#a04e922a2b5d740871f06170b34ac50b6',1,'kmp_flag_atomic']]],
  ['logevent_4',['logEvent',['../group__STATS__GATHERING.html#gga438c2840cc2d516238ea3eb0f4c116b3a53d50e56126850e531164b0bb1848c5e',1,'kmp_stats.h']]]
];
