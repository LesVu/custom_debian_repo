var searchData=
[
  ['ident_0',['ident',['../structident.html',1,'']]],
  ['ident_5ft_1',['ident_t',['../group__BASIC__TYPES.html#gabaf9a1671d9d5fe8d98cf00157cac2aa',1,'kmp.h']]],
  ['internal_5frelease_2',['internal_release',['../classkmp__flag__native.html#a9f7a3f357e6ce7f2be3ee54152336ce3',1,'kmp_flag_native::internal_release()'],['../classkmp__flag__atomic.html#a6e1326998325869d45596c1652627455',1,'kmp_flag_atomic::internal_release()']]],
  ['is_5fsleeping_3',['is_sleeping',['../classkmp__flag__native.html#a96fac1eba784690146edd6450baa1a6b',1,'kmp_flag_native::is_sleeping()'],['../classkmp__flag__atomic.html#a2e6f04aebcb3c03b548886762af47d67',1,'kmp_flag_atomic::is_sleeping()']]],
  ['is_5fsleeping_5fval_4',['is_sleeping_val',['../classkmp__flag__native.html#a505e3d75c18c8694f753994ec74d37c5',1,'kmp_flag_native::is_sleeping_val()'],['../classkmp__flag__atomic.html#a240e573eb4b6abc1dc65ad27ba904d2e',1,'kmp_flag_atomic::is_sleeping_val()']]]
];
