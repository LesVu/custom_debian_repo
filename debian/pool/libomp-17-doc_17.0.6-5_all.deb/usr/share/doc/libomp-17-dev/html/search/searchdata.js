var indexSectionsWithContent =
{
  0: "_abcdfgiklnoprstuw",
  1: "bik",
  2: "_dgilnostu",
  3: "cflnprtw",
  4: "ik",
  5: "s",
  6: "klno",
  7: "abdpstuw",
  8: "l"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "functions",
  3: "variables",
  4: "typedefs",
  5: "enums",
  6: "enumvalues",
  7: "groups",
  8: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Functions",
  3: "Variables",
  4: "Typedefs",
  5: "Enumerations",
  6: "Enumerator",
  7: "Modules",
  8: "Pages"
};

