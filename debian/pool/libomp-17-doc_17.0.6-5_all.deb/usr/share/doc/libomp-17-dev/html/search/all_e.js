var searchData=
[
  ['sched_5ftype_0',['sched_type',['../group__WORK__SHARING.html#ga56ebd4fa33cbb0497e6157bb3f04d0e2',1,'kmp.h']]],
  ['set_1',['set',['../classkmp__flag__atomic.html#a8e8fafb63c404b5779df7c45a78b6689',1,'kmp_flag_atomic']]],
  ['set_5fsleeping_2',['set_sleeping',['../classkmp__flag__native.html#ad9d5e816df9f24cde0ceb06f91cb6836',1,'kmp_flag_native::set_sleeping()'],['../classkmp__flag__atomic.html#a2bdd4112203bc8cb4964da98aa0c6c0f',1,'kmp_flag_atomic::set_sleeping()']]],
  ['set_5fstderr_3',['set_stderr',['../classkmp__safe__raii__file__t.html#a12c4b7eef9f50a1be78699786da78f4a',1,'kmp_safe_raii_file_t']]],
  ['set_5fstdout_4',['set_stdout',['../classkmp__safe__raii__file__t.html#a0329a4f4af75d9bd62fbaf81ce13915f',1,'kmp_safe_raii_file_t']]],
  ['set_5fwaiter_5',['set_waiter',['../classkmp__flag.html#aeb104cf021fd36494e9f3c12612567ba',1,'kmp_flag']]],
  ['startup_20and_20shutdown_6',['Startup and Shutdown',['../group__STARTUP__SHUTDOWN.html',1,'']]],
  ['statistics_20gathering_20from_20omptb_7',['Statistics Gathering from OMPTB',['../group__STATS__GATHERING.html',1,'']]],
  ['stats_5fflags_5fe_8',['stats_flags_e',['../group__STATS__GATHERING.html#ga438c2840cc2d516238ea3eb0f4c116b3',1,'kmp_stats.h']]],
  ['stats_5fstate_5fe_9',['stats_state_e',['../group__STATS__GATHERING.html#gaceceb28b590e725a5106b6c90a451243',1,'kmp_stats.h']]],
  ['store_10',['store',['../classkmp__flag__atomic.html#a14a932b7979ae2db82a57cf05fad91af',1,'kmp_flag_atomic']]],
  ['synchronization_11',['Synchronization',['../group__SYNCHRONIZATION.html',1,'']]]
];
