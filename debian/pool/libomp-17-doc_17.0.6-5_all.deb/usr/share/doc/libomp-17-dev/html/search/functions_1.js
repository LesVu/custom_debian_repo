var searchData=
[
  ['done_5fcheck_0',['done_check',['../classkmp__flag__native.html#abf1de92e8eaaaab3127fa0da0a3c618d',1,'kmp_flag_native::done_check()'],['../classkmp__flag__atomic.html#ae7262726cfbe4c11b60eac442365742e',1,'kmp_flag_atomic::done_check()']]],
  ['done_5fcheck_5fval_1',['done_check_val',['../classkmp__flag__native.html#a5dfed79aa5e7428801236f72050f884f',1,'kmp_flag_native::done_check_val()'],['../classkmp__flag__atomic.html#a7b4c3dd6047260b7ced559deedfb86cb',1,'kmp_flag_atomic::done_check_val()']]]
];
