var searchData=
[
  ['num_5fwaiting_5fthreads_0',['num_waiting_threads',['../classkmp__flag.html#a38f5e2a9e3c7f4a27833c7523be29061',1,'kmp_flag']]]
];
