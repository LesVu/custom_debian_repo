var searchData=
[
  ['notdone_5fcheck_0',['notdone_check',['../classkmp__flag__native.html#a51870e079fa09555e4f9e52c433b9836',1,'kmp_flag_native::notdone_check()'],['../classkmp__flag__atomic.html#a7655e417e181081fe8458370e57100eb',1,'kmp_flag_atomic::notdone_check()']]]
];
