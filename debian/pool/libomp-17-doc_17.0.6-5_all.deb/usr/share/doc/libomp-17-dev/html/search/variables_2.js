var searchData=
[
  ['lazy_5fpriv_0',['lazy_priv',['../structkmp__taskred__flags.html#a8b474dd53a7cf8d81e9e490fad3f2ed9',1,'kmp_taskred_flags']]],
  ['loc_1',['loc',['../classkmp__flag__atomic.html#a04e922a2b5d740871f06170b34ac50b6',1,'kmp_flag_atomic']]]
];
