var searchData=
[
  ['notdone_5fcheck_0',['notdone_check',['../classkmp__flag__native.html#a51870e079fa09555e4f9e52c433b9836',1,'kmp_flag_native::notdone_check()'],['../classkmp__flag__atomic.html#a7655e417e181081fe8458370e57100eb',1,'kmp_flag_atomic::notdone_check()']]],
  ['notinmaster_1',['notInMaster',['../group__STATS__GATHERING.html#gga438c2840cc2d516238ea3eb0f4c116b3a0939773e208cb608fe78bc80a4197523',1,'kmp_stats.h']]],
  ['nototal_2',['noTotal',['../group__STATS__GATHERING.html#gga438c2840cc2d516238ea3eb0f4c116b3ab0da7f248271bb150e59d37370c799b7',1,'kmp_stats.h']]],
  ['nounits_3',['noUnits',['../group__STATS__GATHERING.html#gga438c2840cc2d516238ea3eb0f4c116b3a1c30b5719af4df0bdc7206f20559c6dc',1,'kmp_stats.h']]],
  ['num_5fwaiting_5fthreads_4',['num_waiting_threads',['../classkmp__flag.html#a38f5e2a9e3c7f4a27833c7523be29061',1,'kmp_flag']]]
];
