var searchData=
[
  ['parallel_20_28fork_2fjoin_29_0',['Parallel (fork/join)',['../group__PARALLEL.html',1,'']]],
  ['psource_1',['psource',['../structident.html#a8c2ccc106967f36d7191d59d4d5a65dc',1,'ident']]]
];
