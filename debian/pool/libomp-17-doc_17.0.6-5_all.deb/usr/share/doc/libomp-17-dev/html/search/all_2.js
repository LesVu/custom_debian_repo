var searchData=
[
  ['basic_20types_0',['Basic Types',['../group__BASIC__TYPES.html',1,'']]],
  ['bounds_5finfo_5ft_1',['bounds_info_t',['../structbounds__info__t.html',1,'']]],
  ['bounds_5finfoxx_5ftemplate_2',['bounds_infoXX_template',['../structbounds__infoXX__template.html',1,'']]]
];
