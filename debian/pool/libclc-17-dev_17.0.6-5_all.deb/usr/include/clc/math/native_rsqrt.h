#define __CLC_BODY <clc/math/unary_decl.inc>
#define __CLC_FUNCTION native_rsqrt
#define __FLOAT_ONLY

#include <clc/math/gentype.inc>

#undef __FLOAT_ONLY
#undef __CLC_BODY
#undef __CLC_FUNCTION
